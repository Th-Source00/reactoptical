import React from 'react'

export default function Records() {
  return (
    <div>Records</div>
  )
}
