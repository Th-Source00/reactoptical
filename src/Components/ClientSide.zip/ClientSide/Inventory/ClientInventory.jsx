import React from 'react'

export default function ClientInventory() {
  return (
    <div>ClientInventory</div>
  )
}
