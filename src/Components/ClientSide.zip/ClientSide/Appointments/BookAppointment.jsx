import React from 'react'

export default function BookAppointment() {
  return (
    <div>BookAppointment</div>
  )
}
