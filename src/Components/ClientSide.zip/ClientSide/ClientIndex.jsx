import React from 'react'
import MorrisChart from '../Morris/MorrisChart'
import AppWidgetSummary from '../../Containers/AppView/app-widget-summary'
import Grid from '@mui/material/Unstable_Grid2';

import history from "../../Assets/others-assets/icons/glass/hi-story.png"
import app from "../../Assets/others-assets/icons/glass/appoint.png"
import comments from "../../Assets/others-assets/icons/glass/ic_glass_message.png"
import invent from "../../Assets/others-assets/icons/glass/ic_glass_bag.png"
import MorrisDonut from '../Morris/MorrisDonut';
import { useParams } from 'react-router-dom';


const ClientIndex=()=>{
  const { firstName, lastName } = useParams();

  return (
    <>
      <div>
        <h3>Welcome, {firstName} {lastName}!</h3>
      </div>
      <div className="info-data" >

        <Grid classname='container' spacing={7}>
          <Grid xs={15} sm={10} md={3}>
            <AppWidgetSummary
              title="Records/History"
              total={144}
              color="info"
              icon={<img alt="icon" width={50} height={50} src={history} />}
            />
          </Grid>
          

        </Grid>
        {/* ======================================= */}


        {/* ====================================  */}
        <Grid classname='container' spacing={7}>
          <AppWidgetSummary
            title="Inventory"
            total={130}
            color="info"
            icon={<img alt="icon" width={50} height={50} src={invent} />}

          />
        </Grid>
        <Grid classname='container' spacing={7}>

           <Grid xs={12} sm={10} md={3}>
          <AppWidgetSummary
            title="Appointments "
            total={234}
            color="error"
            icon={<img alt="icon" src={app} />}
          />
        </Grid>
        </Grid>
       
        {/* =============================================================  */}
        
        <Grid xs={12} sm={6} md={3}>
          <AppWidgetSummary
            title="Messages"
            total={234}
            color="info"
            icon={<img alt="icon" src={comments} />}
          />
        </Grid>
      </div>

      <div id="graph-container" className='d-flex'>
        <div >
          <MorrisChart />
        </div>
        <div>
          <MorrisDonut/>
        </div>

      </div>
    </>

  )
}
export default ClientIndex;
