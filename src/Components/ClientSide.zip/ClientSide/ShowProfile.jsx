import React, { useEffect, useState } from 'react'

import "../../Containers/DashBoard/DashStyle.css"

// import SidebarComponent from '../../Components/sidebar/SidebarComponent.jsx'
import ProfileComponent from '../../Components/profile/ProfileComponent.jsx'
import Nav from '../../Components/NavBar/Nav.jsx'


// =========Sidebar IMports===========================

import history from "../../Assets/others-assets/icons/glass/history.png"
import app from "../../Assets/others-assets/icons/glass/app.png"
import comments from "../../Assets/others-assets/icons/glass/comments.png"
import invent from "../../Assets/others-assets/icons/glass/invent.png"



import { Link, Route, Routes } from 'react-router-dom'


import { debounce } from 'lodash'
import ChatWithUs from './Messages/ChatWithUs.jsx'
import BookAppointment from './Appointments/BookAppointment.jsx'
import Records from './History/Records.jsx'
import ClientIndex from './ClientIndex.jsx'
import ClientInventory from './Inventory/ClientInventory.jsx'





export default function ShowProfile() {

	// ================Sidebar Function Section===============================================
	const [isSidebarHidden, setIsSidebarHidden] = useState(false);

	useEffect(() => {
		const sidebar = document.getElementById('sidebar');
		sidebar.addEventListener('mouseleave', handleMouseLeave);
		sidebar.addEventListener('mouseenter', handleMouseEnter);

		return () => {
			sidebar.removeEventListener('mouseleave', handleMouseLeave);
			sidebar.removeEventListener('mouseenter', handleMouseEnter);
		};
	}, []);

	const handleDropdownClick = (e) => {
		e.preventDefault();
		const allDropdowns = document.querySelectorAll('#sidebar .side-dropdown');

		if (!e.target.classList.contains('active')) {
			allDropdowns.forEach(i => {
				const aLink = i.parentElement.querySelector('a:first-child');
				aLink.classList.remove('active');
				i.classList.remove('show');
			});
		}

		e.target.classList.toggle('active');
		e.target.nextElementSibling.classList.toggle('show');
	};

	const toggleSidebar = (e) => {
		const allSideDivider = document.querySelectorAll('#sidebar .divider');
		const sidebar = document.getElementById('sidebar');

		if (sidebar.classList.contains('hide')) {
			allSideDivider.forEach(item => {
				item.textContent = '-';
			});
			const allDropdowns = document.querySelectorAll('#sidebar .side-dropdown');
			allDropdowns.forEach(item => {
				const a = item.parentElement.querySelector('a:first-child');
				a.classList.remove('active');
				item.classList.remove('show');
			});
		} else {
			allSideDivider.forEach(item => {
				item.textContent = item.dataset.text;
			});
		}

		sidebar.classList.toggle('hide');
	};

	const handleMouseLeave = () => {
		if (isSidebarHidden) {
			const allDropdowns = document.querySelectorAll('#sidebar .side-dropdown');
			const allSideDivider = document.querySelectorAll('#sidebar .divider');
			allDropdowns.forEach(item => {
				const a = item.parentElement.querySelector('a:first-child');
				a.classList.remove('active');
				item.classList.remove('show');
			});
			allSideDivider.forEach(item => {
				item.textContent = '-';
			});
		}
	};

	const handleMouseEnter = () => {
		if (isSidebarHidden) {
			const allDropdowns = document.querySelectorAll('#sidebar .side-dropdown');
			const allSideDivider = document.querySelectorAll('#sidebar .divider');
			allDropdowns.forEach(item => {
				const a = item.parentElement.querySelector('a:first-child');
				a.classList.remove('active');
				item.classList.remove('show');
			});
			allSideDivider.forEach(item => {
				item.textContent = item.dataset.text;
			});
		}
	};

	const handleSidebarToggle = () => {
		setIsSidebarHidden(prevState => !prevState);
	};
	// ================================================================

	// const [selectedComponent, setSelectedComponent] = useState(null);
	const [ShowChatWithUs, setShowChatWithUs] = useState(false);
	const [ShowClientInventory, setShowClientInventory] = useState(false);
	const [ShowBookAppointment, setShowBookAppointment] = useState(false);
	const [ShowIndex, setShowIndex] = useState(true);
	const [ShowRecords, setShowRecords] = useState(false);

	const handleClick = debounce((componentNumber) => {
		if (componentNumber === 1) {
			setShowChatWithUs(!ShowChatWithUs);
			setShowClientInventory(false);
			setShowBookAppointment(false);
			setShowIndex(false);
			setShowRecords(false);
		} else if (componentNumber === 2) {
			setShowChatWithUs(false);
			setShowClientInventory(!ShowClientInventory);
			setShowBookAppointment(false);
			setShowIndex(false);
			setShowRecords(false);
		} else if (componentNumber === 3) {
			setShowChatWithUs(false);
			setShowClientInventory(false);
			setShowBookAppointment(!ShowBookAppointment);
			setShowIndex(false);
			setShowRecords(false);
		}
		else if (componentNumber === 4) {
			setShowChatWithUs(false);
			setShowClientInventory(false);
			setShowBookAppointment(false);
			setShowIndex(!ShowIndex);
			setShowRecords(false);
		}
		else if (componentNumber === 5) {
			setShowChatWithUs(false);
			setShowClientInventory(false);
			setShowBookAppointment(false);
			setShowIndex(false);
			setShowRecords(!ShowRecords);
		}
	}, 500);

	useEffect(() => {

		// Persist the state of toggled components across re-renders
		setShowChatWithUs(prevState => prevState);
		setShowClientInventory(prevState => prevState);
		setShowBookAppointment(prevState => prevState);
		setShowIndex(prevState => prevState);
		setShowRecords(prevState => prevState);

	}, []);






	return (
		<div>


			{/* <SidebarComponent /> */}
			{/* =========================================================================== */}
			{/* =========================================================================== */}
			{/* =========================================================================== */}
			<section style={{ margin: "0", padding: "0" }} id="sidebar" className={isSidebarHidden ? 'hide' : ''}>
				<ul className="side-menu">
					<li>
						<a onClick={handleSidebarToggle} href="##" id='dashboard-hamburger' className="active">
							&nbsp;&nbsp; <i className='bx bx-menu bx-md'></i>&nbsp;
							Dashboard
						</a>
					</li>
					<li className="divider" data-text="main">Main</li>
					<div>
						<li ><a href='##' ><img className='img-icon-one' src={app} width={20} height={20} alt='appointment icon' />
							{/* Appointments */}
							<Link onClick={() => handleClick(3)} to="##">
								Book Appointments
							</Link>

						</a>
						</li>
						{/* <li >

							<a><img className='img-icon-two' src={patient} width={20} height={20} alt="patient icon" />
								<Link onClick={() => handleClick(1)} to="#">
									Frame brand & Number/code
								</Link>

							</a>

						</li> */}
						<li >

							<a>	<img className='img-icon-three' src={invent} width={20} height={20} alt="inventory icon" />
								<Link onClick={() => handleClick(2)} to="#">
									Inventory
								</Link>
							</a>

						</li>
						<li >

							<a>	<img className='img-icon-three' src={history} width={20} height={20} alt="inventory icon" />
								<Link onClick={() => handleClick(5)} to="#">
									History /Records
								</Link>
							</a>

						</li>
						<li className="divider" data-text="Register"> Talk to Admin</li>
						<li ><a target='_parent' href="##"> <img className='img-icon-eight' src={comments} width={20} height={20} alt="register icon " />
							<Link onClick={() => handleClick(1)} to="##">
								Chat  with us
							</Link>

						</a></li>
					</div>
				</ul>
				<div className="ads">
					<div className="wrapper">
						<a href="##" className="btn-upgrade">Upgrade</a>
						<p>Become a <span>PRO</span> member and enjoy <span>All Features</span></p>
					</div>
				</div>
			</section>

			{/* <!-- SIDEBAR --> */}
			{/* ============================================================================ */}
			{/* ============================================================================ */}
			{/* ============================================================================ */}
			{/* ============================================================================ */}
			{/* <!-- NAVBAR --> */}
			<section id="content">

				{/* <!-- NAVBAR --> */}
				< nav >

					<Nav />
					<span className="divider"></span>
					{/* ------------Profile Component-------- */}
					<div >
						<ProfileComponent />
					</div>

					{/* ------------Profile Component-------- */}
				</nav>
				{/* <!-- NAVBAR --> */}

				{/* <!-- MAIN --> */}
				<main>


					<div>
						<div>

							{ShowChatWithUs && <ChatWithUs />}
							{ShowBookAppointment && <BookAppointment />}
							{ShowClientInventory && <ClientInventory />}
							{ShowRecords && <Records />}
							{ShowIndex && <ClientIndex />}

						</div>
					</div>
				</main>
				{/* <!-- MAIN --> */}
				
				<div>


				</div>

			</section>
			{/* <!-- NAVBAR --> */}

			{/* // <script src="script.js"></script> */}
		</div >
	)
}

